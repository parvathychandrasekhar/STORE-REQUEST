from odoo import models, fields, api, _

class BOMPreviewLines(models.Model):
    _name = 'bom.preview.line'
    _description = 'BOM PreView'

    bom_id = fields.Many2one('mrp.bom', string='BOM reference')
    product_id = fields.Many2one('product.template', string='Components')
    uom_id = fields.Many2one('uom.uom', string='UOM')
    qty = fields.Float(string='Qty', digits=(16, 5))
    price = fields.Float(string='Price')
    qty_available = fields.Float(related='product_id.qty_available', string='Available')
    virtual_available = fields.Float(related='product_id.virtual_available', string='Forecast')
    product_uom_id = fields.Many2one('uom.uom', related='product_id.uom_id', string='UoM in Product', store=True)

    @api.onchange('product_id')
    def _onchange_product_id(self):
        if not self.product_id:
            return
        if self.product_id:
            self.uom_id = self.product_id.uom_id.id
            self.qty = 1.0
            self.price = self.product_id.list_price