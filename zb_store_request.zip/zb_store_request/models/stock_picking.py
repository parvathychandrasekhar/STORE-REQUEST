from odoo import models, fields, api, _


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    stock_request_line_id = fields.Many2one('stock.request.lines', string='Stock Request Line')
    stock_request_id = fields.Many2one('stock.request', string='Stock Request')
    request_to = fields.Many2one('res.users', required=False, tracking=True, copy=False)
    product_and_qty = fields.Text(compute='_compute_product_and_qty', string='Product and QTY', store=False)

    @api.depends('move_ids_without_package', 'move_ids_without_package.product_id',
                 'move_ids_without_package.product_uom_qty')
    def _compute_product_and_qty(self):
        for rec in self:
            if rec.move_ids_without_package:
                product_lines = [
                    f" [{move.product_id.display_name}  :  {move.product_uom_qty}]"
                    for move in rec.move_ids_without_package
                    if move.product_id and move.product_uom_qty
                ]
                rec.product_and_qty = "\n".join(product_lines)
            else:
                rec.product_and_qty = ""