from odoo import fields, api, models, _
from odoo.exceptions import ValidationError,UserError
import math
import logging
_logger = logging.getLogger(__name__)


class StockRequest(models.Model):
    _name = 'stock.request'
    _description = 'Stock Request'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'create_date desc, id desc'

    # _rec_name = 'name'

    @api.onchange('related_sale_id')
    def _compute_sale_domain(self):
        for record in self:
            orders = self.env['sale.order'].search([('state', '=', 'sale')])
            print("SSSSSSSSSSSSSSSSSSSSSs",orders.ids)
            record.related_sale_domain = [
                    ('id', 'in', orders.ids)
                ]
            print("SSSSSSSSSSSSSSSSSSSSSs",record.related_sale_domain)

    @api.onchange('related_sale_id')
    def _compute_order_line_domain(self):
        for rec in self:
            if rec.related_sale_id:
                rec.order_line_domain = [
                    ('id', 'in', rec.related_sale_id.order_line.ids)
                ]
            else:
                rec.order_line_domain = [()]  # Return empty domain instead of [()]
                print("-------------------rec.order_line_domain----------------------",rec.order_line_domain)


    name = fields.Char(string="Request No",default=lambda self: _('New'),copy=False)
    create_date = fields.Datetime(string="Date",required=True, copy=False,help="Creation date.",default=fields.Datetime.now)
    request_line_ids = fields.One2many('stock.request.lines','stock_request_id','Stock Request Line')
    picking_type_id = fields.Many2one('stock.picking.type', 'Operation Type',required=True)
    related_sale_id = fields.Many2one('sale.order', string="Sale order",copy=False)
    order_line_id = fields.Many2one('sale.order.line',string='Sale Order Line',copy=False)
    demanded_qty = fields.Float(string='Demanded Quantity',readonly=True,compute='compute_demanded_qty',store=True,help="While selecting a product in order line for a sale order the demanded qty is computed.")
    # order_line_ids = fields.Many2many(comodel_name='sale.order.line',string="Sale Order Line IDs",relation='stock_request_orderline_rel',column1='request_id',column2='orderline_id',readonly=True)
    # related_sale_ids = fields.Many2many(comodel_name='sale.order',string="Sale Order Line IDs",relation='stock_request_sale_order_rel',column1='store_request_id',column2='order_id',readonly=True)
    order_line_domain = fields.Binary(compute='_compute_order_line_domain', string="Order Line Domain")
    related_sale_domain = fields.Binary(compute='_compute_sale_domain', string="Related Sale Domain")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('transfer', 'Transfer'),
        ('done', 'Done'),
        ], string='Status',default='draft')
    request_to = fields.Many2one('res.users',tracking=True,copy=False)
    validated_picking_count = fields.Integer(compute='_compute_validated_picking_count', string='Picking Count')
    non_validated_picking_count = fields.Integer(compute='_compute_non_validated_picking_count', string='Picking Count(Non - Validated)')
    src_loc_id = fields.Many2one('stock.location', compute='_compute_source_location',string="Source Location",store=True,copy=False)
    is_re_requested = fields.Boolean(string='Is Re-Request')
    bom_id = fields.Many2one('mrp.bom', string='Bills Of Materials',copy=False)

    def re_request_transfer(self):
        for rec in self:
            rec.is_re_requested = True

    def unlink(self):
        for line in self:
            moves = self.env['stock.move'].search([
                ('stock_request_id', '=', line.id)
            ])
            for move in moves:
                move.write({
                    'is_requested': False,
                    'stock_request_id': False,
                    'stock_request_count': 0,
                })
                if move.picking_id:
                    move.picking_id.is_requested = False
        return super(StockRequest, self).unlink()



    @api.depends('picking_type_id','picking_type_id.default_location_src_id')
    def _compute_source_location(self):
        for record in self:
            record.src_loc_id = record.picking_type_id.default_location_src_id

    @api.depends('request_line_ids.picking_ids', 'request_line_ids.picking_ids.state')
    def _compute_non_validated_picking_count(self):
        for record in self:
            non_validated_pickings = record.request_line_ids.mapped('picking_ids').filtered(lambda p: p.state not in ('done', 'cancel'))
            record.non_validated_picking_count = len(non_validated_pickings)



    @api.depends('request_line_ids.picking_ids')
    def action_view_non_validated_transfer(self):
        """
        Display only non validated pickings state not in ('done', 'cancel') associated with the stock request lines.
        Returns an action to show the non validated pickings in a list/form view.
        """
        self.ensure_one()
        # Collect only non validated pickings state not in ('done', 'cancel') from request lines
        non_validated_pickings = self.request_line_ids.mapped('picking_ids').filtered(lambda p: p.state not in ('done', 'cancel'))

        # Create the action dictionary
        action = {
            'name': _('Non Validated Transfers'),
            'type': 'ir.actions.act_window',
            'res_model': 'stock.picking',
            'view_mode': 'list,form',
            "views": [[self.env.ref("zb_store_request.view_picking_tree_store_request").id, "list"], [False, "form"]],
            'domain': [('id', 'in', non_validated_pickings.ids)],
            'context': {'create': False}  # Disable creation of new records from this view
        }

        # If there's only one non validated picking, show the form view directly
        if len(non_validated_pickings) == 1:
            action.update({
                'view_mode': 'form',
                'res_id': non_validated_pickings.id,
            })

        return action



    @api.depends('request_line_ids.picking_ids', 'request_line_ids.picking_ids.state')
    def _compute_validated_picking_count(self):
        for record in self:
            validated_pickings = record.request_line_ids.mapped('picking_ids').filtered(lambda p: p.state == 'done')
            record.validated_picking_count = len(validated_pickings)


    @api.depends('request_line_ids.picking_ids')
    def action_view_transfer(self):
        """
        Display only validated pickings (state = 'done') associated with the stock request lines.
        Returns an action to show the validated pickings in a list/form view.
        """
        self.ensure_one()
        # Collect only validated pickings (state = 'done') from request lines
        validated_pickings = self.request_line_ids.mapped('picking_ids').filtered(lambda p: p.state == 'done')

        # Create the action dictionary
        action = {
            'name': _('Validated Transfers'),
            'type': 'ir.actions.act_window',
            'res_model': 'stock.picking',
            'view_mode': 'list,form',
            "views": [[self.env.ref("zb_store_request.view_picking_tree_store_request").id, "list"], [False, "form"]],
            'domain': [('id', 'in', validated_pickings.ids)],
            'context': {'create': False}  # Disable creation of new records from this view
        }

        # If there's only one validated picking, show the form view directly
        if len(validated_pickings) == 1:
            action.update({
                'view_mode': 'form',
                'res_id': validated_pickings.id,
            })

        return action

    # def unlink(self):
    #     for record in self:
    #         if record.state in ['transfer', 'done']:
    #             raise UserError(_("You cannot delete a record that is in 'transfer' or 'done' state."))
    #     return super(StockRequest, self).unlink()

    def action_send_store_request_mail(self):
        template = self.env.ref('zb_guardian_control_customizations.email_template_store_request')
        template.send_mail(self.id,force_send=True)

    # def action_done(self):
    #     for rec in self:
    #         for line in rec.request_line_ids:
    #             if any(line.is_requirement_satisfied for line in rec.request_line_ids):
    #                 raise UserError(_("The product %s has pending quantity to be transferred.") % line.product_id.name)
    def action_done(self):
        for rec in self:
            unsatisfied_lines = [line for line in rec.request_line_ids if not line.is_requirement_satisfied]
            if unsatisfied_lines:
                product_names = ', '.join([line.product_id.name for line in unsatisfied_lines])
                raise UserError(_("The following products have pending quantities to be transferred: %s") % product_names)
            else:
                rec.state = 'done'

    def action_store_request(self):
        for rec in self:
            rec.state = 'transfer'
            # rec.action_send_store_request_mail()


    @api.depends('order_line_id')
    def compute_demanded_qty(self):
        for rec in self:
            if rec.order_line_id:
                print(".....................rec.order_line_id.........................",rec.order_line_id)
                rec.demanded_qty=rec.order_line_id.product_uom_qty
            else:
                rec.demanded_qty =0.0


    @api.onchange('order_line_id')
    def _onchange_select_bom_id(self):
        self.request_line_ids = [(5, 0, 0)]
        list=[]
        # Guard against _unknown()
        if not self.order_line_id or not self.order_line_id.id:
            print("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDself.request_line_ids.........................", self.request_line_ids)
            return
        bom = self.order_line_id.product_template_id.bom_ids[:1]  # Get the first BOM safely
        if bom and bom.preview_line_ids:
            new_lines = []
            for item in bom.preview_line_ids:
                new_line = {
                    'product_id': item.product_id.product_variant_id.id,
                    'required_qty': item.qty * self.order_line_id.product_uom_qty,
                    'product_uom': item.uom_id.id,
                }
                new_lines.append((0, 0, new_line))
            self.request_line_ids = new_lines

    @api.onchange('bom_id')
    def _onchange_bill_of_material_id(self):
        self.request_line_ids = [(5, 0, 0)]
        list = []
        # Guard against _unknown()
        if not self.bom_id or not self.bom_id.id:
            print("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDself.request_line_ids.........................", self.request_line_ids)
            return
        # bom = self.bom_id.product_template_id.bom_ids[:1]  # Get the first BOM safely
        if self.bom_id and self.bom_id.preview_line_ids:
            new_lines = []
            for item in self.bom_id.preview_line_ids:
                new_line = {
                    'product_id': item.product_id.product_variant_id.id,
                    'required_qty': 0.0,
                    'product_uom': item.uom_id.id,
                }
                new_lines.append((0, 0, new_line))
            self.request_line_ids = new_lines

    #=== CRUD METHODS ===#

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _("New")) == _("New"):
                seq_date = fields.Datetime.context_timestamp(
                    self, fields.Datetime.to_datetime(vals['create_date'])
                ) if 'create_date' in vals else None
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'stock.request', sequence_date=seq_date) or _("New")

        return super().create(vals_list)

class StockRequestLines(models.Model):
    _name = "stock.request.lines"
    _description = "Stock Request Line"

    name = fields.Char(string="Request Line No")
    stock_request_id = fields.Many2one('stock.request', 'Stock Request')
    product_id = fields.Many2one('product.product', 'Product',domain="[('type', 'in', ['product', 'consu'])]",required=True)
    required_qty = fields.Float(string="Required Qty",digits='Product Unit of Measure',required=True)
    qty_to_transfer = fields.Float(string="Qty to Transfer",digits='Product Unit of Measure',)
    transferred_qty = fields.Float(string="Transferred Qty",digits=(16, 5))
    pending_qty = fields.Float(string="Pending Qty", digits='Product Unit of Measure',compute="_compute_pending_qty", store=True)
    lot_id = fields.Many2one('stock.lot', string="Lot", domain="[('product_id', '=', product_id)]")
    picking_ids = fields.One2many('stock.picking','stock_request_line_id','Pickings')
    # color = fields.Integer(string='Color Index', compute='_compute_color')
    transferred_lot_ids = fields.Many2many('stock.lot', string="Transferred Lots", readonly=True)
    has_unvalidated_transfer = fields.Boolean(compute='_compute_has_unvalidated_transfer', store=True)
    is_requirement_satisfied = fields.Boolean(string='Is Requirement Satisfied')
    product_uom = fields.Many2one('uom.uom', "UoM", required=True)



    def unlink(self):
        for line in self:
            moves = self.env['stock.move'].search([
                ('stock_request_id', '=', line.stock_request_id.id)
            ])
            for move in moves:
                move.write({
                    'is_requested': False,
                    'stock_request_id': False,
                    'stock_request_count': 0,
                })
                if move.picking_id:
                    move.picking_id.is_requested = False
        return super(StockRequestLines, self).unlink()

    def action_send_product_transfer_mail(self):
        template = self.env.ref('zb_guardian_control_customizations.email_template_product_transfer')
        template.send_mail(self.id,force_send=True)


    @api.depends('picking_ids', 'picking_ids.state')
    def _compute_has_unvalidated_transfer(self):
        for line in self:
            line.has_unvalidated_transfer = bool(line.picking_ids.filtered(lambda p: p.state not in ['done', 'cancel']))

    @api.depends('required_qty', 'transferred_qty')
    def _compute_pending_qty(self):
        for line in self:
            line.pending_qty = line.required_qty - line.transferred_qty



    # @api.depends('picking_ids.state')
    # def _compute_color(self):
    #     for line in self:
    #         if any(picking.state == 'done' for picking in line.picking_ids):
    #             line.color = 2  # Red color
    #         else:
    #             line.color = 0

    def action_validate(self):
        print("---------------vallllllllllllllll---------------")
        for picking in self.picking_ids:
            if picking.state=='assigned':
                    status=picking.button_validate()
                    if status:
                        moves = picking.move_ids_without_package.filtered(lambda m: m.product_id == self.product_id)
                        for move in moves:
                        # Get the lots from the move lines
                            lots = move.move_line_ids.mapped('lot_id')
                            self.transferred_lot_ids |= lots
                        self.transferred_qty = round(self.qty_to_transfer + self.transferred_qty, 2)
                        print("------------self.transferred_qty------------",self.transferred_qty)
                        self.pending_qty = self.required_qty-self.transferred_qty
                        print("------------self.required_qty------------",self.required_qty)
                        print("------------self.pending_qty------------",self.pending_qty)
                        if math.isclose(self.required_qty, self.transferred_qty, abs_tol=0.01):
                            print("------------qty-----------")
                            self.is_requirement_satisfied = True
                            print("--------------------is_requirement_satisfied----------------------------------",self.is_requirement_satisfied)
                        # self.action_send_product_transfer_mail()
                        self.qty_to_transfer = 0
        # self._compute_color()



    def action_transfer(self):
        for line in self:
            available_qty_stock_uom = self.env['stock.quant']._get_available_quantity(line.product_id, line.stock_request_id.picking_type_id.default_location_src_id, strict=False)
            print("--------------------available_qty_stock_uom----------------------------------",available_qty_stock_uom)
            stock_uom = line.product_id.uom_id
            # Convert the available quantity to the UoM defined in our model
            print("---------stock_uom-------------",stock_uom.uom_type)
            if stock_uom.uom_type=='reference' or line.product_uom.uom_type =='reference':
                available_qty = stock_uom._compute_quantity(
                    available_qty_stock_uom,
                    line.product_uom
                )
                print("--------------------available_qty1----------------------------------",available_qty)
                qty_to_transfer_stock_uom = line.product_uom._compute_quantity(line.qty_to_transfer,stock_uom)
                print("--------------------qty_to_transfer_stock_uom----------------------------------",qty_to_transfer_stock_uom)
            else:
                available_qty = line.product_uom._compute_quantity(
                    available_qty_stock_uom,
                    stock_uom
                )
                print("--------------------available_qty2----------------------------------",available_qty)
                qty_to_transfer_stock_uom = stock_uom._compute_quantity(line.qty_to_transfer,line.product_uom)
                print("--------------------qty_to_transfer_stock_uom----------------------------------",qty_to_transfer_stock_uom)
            assigned_picking = line.picking_ids.filtered(lambda p: p.state == 'assigned')
            if assigned_picking:
                raise ValidationError(_(" Please validate the Existing Transfer First"))
            if line.qty_to_transfer == 0:
                raise UserError(_("Please set quantity to transfer for product %s") % line.product_id.name)
            if line.pending_qty <= 0:
                line.qty_to_transfer = 0.0
                print("Updated qty_to_transfer:", line.qty_to_transfer)
                raise UserError(_("There is no pending quantity to transfer for product %s") % line.product_id.name)
            if line.transferred_qty == line.required_qty:
                raise UserError(_("The requirement for the product %s has been satisfied") % line.product_id.name)


            if line.qty_to_transfer > available_qty:
                raise UserError(_("There is not enough stock for the product %s in location %s.The quantity available in this location is %s") % (line.product_id.name, line.stock_request_id.picking_type_id.default_location_src_id.name,available_qty))
            if (line.qty_to_transfer+line.transferred_qty) > line.required_qty:
                raise UserError(_("Quantity exceeded for product %s than required") % line.product_id.name)
            # Create picking
            if line.qty_to_transfer != 0:
                picking = self.env['stock.picking'].create({
                    'picking_type_id': line.stock_request_id.picking_type_id.id,
                    'location_id': line.stock_request_id.picking_type_id.default_location_src_id.id,
                    'location_dest_id': line.stock_request_id.picking_type_id.default_location_dest_id.id,
                    'stock_request_line_id': line.id,
                    'request_to':line.stock_request_id.request_to.id,
                })
                print("--------------------picking----------------------------------",picking)

                # Create move
                move = self.env['stock.move'].create({
                    'name': line.product_id.name,
                    'product_id': line.product_id.id,
                    'product_uom_qty': qty_to_transfer_stock_uom,
                    'product_uom': line.product_id.uom_id.id,
                    'picking_id': picking.id,
                    'location_id': picking.location_id.id,
                    'location_dest_id': picking.location_dest_id.id,
                })
                print("--------------------move----------------------------------",move)
                # Confirm the picking
                picking.action_confirm()
                # Assign the picking
                picking.action_assign()
                if picking.state!='assigned':
                    raise UserError(_("No Stock for product %s") % line.product_id.name)







