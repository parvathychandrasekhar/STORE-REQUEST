from odoo import models, fields, api, _


class MrpBom(models.Model):
    _inherit = 'mrp.bom'

    preview_line_ids = fields.One2many("bom.preview.line", "bom_id", string=" ", nolabel=1)