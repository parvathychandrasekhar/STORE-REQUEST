{
    "name": "Store Request",
    "summary": "Internal Request for store Items",
    "version": "18.0.0.0.0",
    "license": "LGPL-3",
    "author": "PARVATHY MENON K S",
    "category": "Warehouse Management",
    "depends": ['stock','sale'],
    "data": [
        'security/ir.model.access.csv',
        'data/ir_sequence_data.xml',
        'views/mrp_bom_views.xml',
        'views/stock_request_view.xml',
        'views/stock_picking_view.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
